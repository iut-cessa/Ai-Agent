CREATE TABLE Manufacture (
    ID INT PRIMARY KEY,
    Name VARCHAR(255) NOT NULL,
    Country VARCHAR(255)
);

CREATE TABLE Car (
    ID INT PRIMARY KEY,
    PlateNumber VARCHAR(50) UNIQUE NOT NULL,
    Model VARCHAR(255),
    Year INT,
    Color VARCHAR(100),
    Status VARCHAR(100),
    ManufactureID INT,
    FOREIGN KEY (ManufactureID) REFERENCES Manufacture(ID)
);

CREATE TABLE Customer (
    ID INT PRIMARY KEY,
    FullName VARCHAR(255) NOT NULL,
    NationalID VARCHAR(50) UNIQUE NOT NULL,
    PhoneNumber VARCHAR(50),
    Email VARCHAR(255),
    Address VARCHAR(500)
);

CREATE TABLE Account (
    AccountNumber VARCHAR(50) NOT NULL,
    CustomerID INT NOT NULL,
    BankName VARCHAR(255),
    PRIMARY KEY (AccountNumber, CustomerID),
    FOREIGN KEY (CustomerID) REFERENCES Customer(ID)
);

CREATE TABLE Reservation (
    ID INT PRIMARY KEY,
    CustomerID INT,
    CarID INT,
    StartDate DATE,
    EndDate DATE,
    FOREIGN KEY (CustomerID) REFERENCES Customer(ID),
    FOREIGN KEY (CarID) REFERENCES Car(ID)
);

CREATE TABLE Payment (
    ID INT PRIMARY KEY,
    ReservationID INT,
    Amount DECIMAL(10,2),
    PaymentDate DATE,
    AccountNumber VARCHAR(50),
    CustomerID INT,
    FOREIGN KEY (ReservationID) REFERENCES Reservation(ID),
    FOREIGN KEY (AccountNumber, CustomerID) REFERENCES Account(AccountNumber, CustomerID)
);

CREATE TABLE Employee (
    ID INT PRIMARY KEY,
    FullName VARCHAR(255) NOT NULL,
    Position VARCHAR(100),
    PhoneNumber VARCHAR(50),
    Email VARCHAR(255),
    Salary DECIMAL(10,2),
    NationalID VARCHAR(50) UNIQUE
);

CREATE TABLE Repairment (
    ID INT PRIMARY KEY,
    CarID INT,
    EmployeeID INT,
    RepairDate DATE,
    Cost DECIMAL(10,2),
    FOREIGN KEY (CarID) REFERENCES Car(ID),
    FOREIGN KEY (EmployeeID) REFERENCES Employee(ID)
);

INSERT INTO Manufacture (ID, Name, Country) VALUES
(1, 'Toyota', 'Japan'),
(2, 'BMW', 'Germany'),
(3, 'Hyundai', 'South Korea'),
(4, 'Peugeot', 'France'),
(5, 'Chevrolet', 'USA');

INSERT INTO Car (ID, PlateNumber, Model, Year, Color, Status, ManufactureID) VALUES
(1, '12A345', 'Corolla', 2020, 'White', 'Available', 1),
(2, '34B678', 'Camry', 2021, 'Black', 'Rented', 1),
(3, '56C910', 'i30', 2019, 'Blue', 'Available', 3),
(4, '78D112', '208', 2022, 'Red', 'Available', 4),
(5, '90E314', 'X5', 2021, 'Grey', 'Maintenance', 2);

INSERT INTO Customer (ID, FullName, NationalID, PhoneNumber, Email, Address) VALUES
(1, 'Ali Rezaei', '1234567890', '09121234567', 'ali@example.com', 'Tehran'),
(2, 'Sara Ahmadi', '2234567890', '09129876543', 'sara@example.com', 'Mashhad'),
(3, 'Reza Hosseini', '3234567890', '09125556677', 'reza@example.com', 'Isfahan'),
(4, 'Maryam Karimi', '4234567890', '09121112233', 'maryam@example.com', 'Tabriz'),
(5, 'Hassan Gholami', '5234567890', '09129998877', 'hassan@example.com', 'Shiraz');

INSERT INTO Account (AccountNumber, CustomerID, BankName) VALUES
('AC1001', 1, 'Melli Bank'),
('AC1002', 2, 'Tejarat Bank'),
('AC1003', 3, 'Saman Bank'),
('AC1004', 4, 'Pasargad Bank'),
('AC1005', 5, 'Melli Bank');

INSERT INTO Reservation (ID, CustomerID, CarID, StartDate, EndDate) VALUES
(1, 1, 1, '2025-08-01', '2025-08-05'),
(2, 2, 2, '2025-08-02', '2025-08-07'),
(3, 3, 3, '2025-08-03', '2025-08-06'),
(4, 4, 4, '2025-08-04', '2025-08-08'),
(5, 5, 1, '2025-08-05', '2025-08-09');

INSERT INTO Payment (ID, ReservationID, Amount, PaymentDate, AccountNumber, CustomerID) VALUES
(1, 1, 1500.00, '2025-08-01', 'AC1001', 1),
(2, 2, 2000.00, '2025-08-02', 'AC1002', 2),
(3, 3, 1200.00, '2025-08-03', 'AC1003', 3),
(4, 4, 1700.00, '2025-08-04', 'AC1004', 4),
(5, 5, 800.00,  '2025-08-05', 'AC1005', 5);

INSERT INTO Employee (ID, FullName, Position, PhoneNumber, Email, Salary, NationalID) VALUES
(1, 'Mohammad Jafari', 'Mechanic', '09120000001', 'mohammad@example.com', 8000.00, '9991112221'),
(2, 'Fatemeh Moradi', 'Receptionist', '09120000002', 'fatemeh@example.com', 6000.00, '9991112222'),
(3, 'Hamid Abbasi', 'Manager', '09120000003', 'hamid@example.com', 12000.00, '9991112223'),
(4, 'Zahra Shiri', 'Mechanic', '09120000004', 'zahra@example.com', 8500.00, '9991112224'),
(5, 'Saeed Kiani', 'Cleaner', '09120000005', 'saeed@example.com', 4000.00, '9991112225');

INSERT INTO Repairment (ID, CarID, EmployeeID, RepairDate, Cost) VALUES
(1, 5, 1, '2025-07-20', 500.00),
(2, 2, 4, '2025-07-22', 300.00),
(3, 3, 1, '2025-07-25', 450.00),
(4, 5, 4, '2025-07-28', 600.00),
(5, 4, 1, '2025-07-30', 200.00);

--Views

--first view
CREATE VIEW FrequentCustomers AS
SELECT c.ID, c.FullName, COUNT(r.ID) AS ReservationCount
FROM Customer c
JOIN Reservation r ON c.ID = r.CustomerID
GROUP BY c.ID, c.FullName
HAVING COUNT(r.ID) > 3;

--second view
CREATE VIEW PaymentsPerReservation AS
SELECT p.ID AS PaymentID, p.Amount, p.PaymentDate, r.ID AS ReservationID, c.FullName
FROM Payment p
JOIN Reservation r ON p.ReservationID = r.ID
JOIN Customer c ON r.CustomerID = c.ID;

--Triggers

--function of first trigger
CREATE OR REPLACE FUNCTION update_car_status_on_repair()
RETURNS TRIGGER AS $$
BEGIN
    UPDATE Car
    SET Status = 'Maintenance'
    WHERE ID = NEW.CarID;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

--first trigger
CREATE TRIGGER trg_update_car_status_on_repair
AFTER INSERT ON Repairment
FOR EACH ROW
EXECUTE FUNCTION update_car_status_on_repair();

--second of first trigger
CREATE OR REPLACE FUNCTION prevent_duplicate_payment()
RETURNS TRIGGER AS $$
BEGIN
    IF EXISTS (
        SELECT 1
        FROM Payment
        WHERE ReservationID = NEW.ReservationID
    ) THEN
        RAISE EXCEPTION 'Duplicate payment for this reservation is not allowed.';
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

--second trigger
CREATE TRIGGER trg_prevent_duplicate_payment
BEFORE INSERT ON Payment
FOR EACH ROW
EXECUTE FUNCTION prevent_duplicate_payment();

--Procedures

--first procedure
CREATE OR REPLACE PROCEDURE get_total_payment_by_customer_proc(p_customer_id INT)
LANGUAGE plpgsql
AS $$
DECLARE
    total_amount NUMERIC(10,2);
BEGIN
    SELECT COALESCE(SUM(Amount), 0) INTO total_amount
    FROM Payment
    WHERE CustomerID = p_customer_id;

    RAISE NOTICE 'Total payment for customer % is: %', p_customer_id, total_amount;
END;
$$;

--second procedure
CREATE OR REPLACE PROCEDURE create_reservation_proc(
    p_customer_id INT,
    p_car_id INT,
    p_start_date DATE,
    p_end_date DATE
)
LANGUAGE plpgsql
AS $$
DECLARE
    conflicting_count INT;
BEGIN
    IF p_start_date > p_end_date THEN
        RAISE EXCEPTION 'Start date must be before or equal to end date.';
    END IF;

    SELECT COUNT(*) INTO conflicting_count
    FROM Reservation
    WHERE CarID = p_car_id
      AND (p_start_date, p_end_date) OVERLAPS (StartDate, EndDate);

    IF conflicting_count > 0 THEN
        RAISE EXCEPTION 'Car is already reserved during the requested period.';
    END IF;

    INSERT INTO Reservation (ID, CustomerID, CarID, StartDate, EndDate)
    VALUES (
        (SELECT COALESCE(MAX(ID), 0) + 1 FROM Reservation),
        p_customer_id,
        p_car_id,
        p_start_date,
        p_end_date
    );

    RAISE NOTICE 'Reservation created successfully.';
END;
$$;

--Functions

--first function
CREATE OR REPLACE FUNCTION get_reservation_count(p_customer_id INT)
RETURNS INT AS $$
DECLARE
    res_count INT;
BEGIN
    SELECT COUNT(*) INTO res_count
    FROM Reservation
    WHERE CustomerID = p_customer_id;

    RETURN res_count;
END;
$$ LANGUAGE plpgsql;

--second function
CREATE OR REPLACE FUNCTION get_discount_percentage(p_customer_id INT)
RETURNS NUMERIC AS $$
DECLARE
    res_count INT;
    discount NUMERIC;
BEGIN
    SELECT COUNT(*) INTO res_count
    FROM Reservation
    WHERE CustomerID = p_customer_id;
    IF res_count < 3 THEN
        discount := 0;
    ELSIF res_count BETWEEN 3 AND 5 THEN
        discount := 5;
    ELSIF res_count BETWEEN 6 AND 10 THEN
        discount := 10;
    ELSE
        discount := 15;
    END IF;

    RETURN discount;
END;
$$ LANGUAGE plpgsql;


--Normalization
CREATE TABLE Manufacture (
    ID INT PRIMARY KEY,
    Name VARCHAR(255) NOT NULL,
    Country VARCHAR(255)
);

CREATE TABLE Car (
    ID INT PRIMARY KEY,
    PlateNumber VARCHAR(50) UNIQUE NOT NULL,
    Model VARCHAR(255),
    Year INT,
    Color VARCHAR(100),
    Status VARCHAR(100),
    ManufactureID INT,
    FOREIGN KEY (ManufactureID) REFERENCES Manufacture(ID)
);

CREATE TABLE Customer (
    ID INT PRIMARY KEY,
    FullName VARCHAR(255) NOT NULL,
    NationalID VARCHAR(50) UNIQUE NOT NULL,
    PhoneNumber VARCHAR(50),
    Email VARCHAR(255),
    Address VARCHAR(500)
);

CREATE TABLE Bank (
    AccountNumber VARCHAR(50) PRIMARY KEY,
    BankName VARCHAR(255)
);

CREATE TABLE Account (
    AccountNumber VARCHAR(50),
    CustomerID INT,
    PRIMARY KEY (AccountNumber, CustomerID),
    FOREIGN KEY (CustomerID) REFERENCES Customer(ID),
    FOREIGN KEY (AccountNumber) REFERENCES Bank(AccountNumber)
);

CREATE TABLE Reservation (
    ID INT PRIMARY KEY,
    CustomerID INT,
    CarID INT,
    StartDate DATE,
    EndDate DATE,
    FOREIGN KEY (CustomerID) REFERENCES Customer(ID),
    FOREIGN KEY (CarID) REFERENCES Car(ID)
);

CREATE TABLE Payment (
    ID INT PRIMARY KEY,
    ReservationID INT,
    Amount DECIMAL(10,2),
    PaymentDate DATE,
    AccountNumber VARCHAR(50),
    FOREIGN KEY (ReservationID) REFERENCES Reservation(ID),
    FOREIGN KEY (AccountNumber) REFERENCES Bank(AccountNumber)
);

CREATE TABLE Employee (
    ID INT PRIMARY KEY,
    FullName VARCHAR(255) NOT NULL,
    Position VARCHAR(100),
    PhoneNumber VARCHAR(50),
    Email VARCHAR(255),
    Salary DECIMAL(10,2),
    NationalID VARCHAR(50) UNIQUE
);

CREATE TABLE Repairment (
    ID INT PRIMARY KEY,
    CarID INT,
    EmployeeID INT,
    RepairDate DATE,
    Cost DECIMAL(10,2),
    FOREIGN KEY (CarID) REFERENCES Car(ID),
    FOREIGN KEY (EmployeeID) REFERENCES Employee(ID)
);

SELECT * FROM FrequentCustomers;

SELECT * FROM PaymentsPerReservation;

SELECT ID, Status FROM Car WHERE ID = 1;
INSERT INTO Repairment (ID, CarID, EmployeeID, RepairDate, Cost)
VALUES (10, 1, 1, '2025-08-12', 400);
SELECT ID, Status FROM Car WHERE ID = 1;

INSERT INTO Payment (ID, ReservationID, Amount, PaymentDate, AccountNumber, CustomerID)
VALUES (10, 1, 1500, '2025-08-12', 'AC1001', 1);

CALL get_total_payment_by_customer_proc(1);

CALL create_reservation_proc(1, 3, '2025-08-15', '2025-08-17');
CALL create_reservation_proc(1, 3, '2025-08-20', '2025-08-18');
CALL create_reservation_proc(1, 1, '2025-08-04', '2025-08-06');


SELECT get_reservation_count(1);
SELECT get_reservation_count(3);

SELECT get_discount_percentage(1);
SELECT get_discount_percentage(3);
